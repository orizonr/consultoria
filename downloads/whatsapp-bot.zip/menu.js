// menu.js — WhatsApp Bot
// Edite os textos dos menus e fluxos para o seu negócio
'use strict';

const CFG               = require('./config');
const TIMEOUT_ESTADO_MS = CFG.TIMEOUT_ESTADO_MS;
const ATEND             = CFG.ATENDIMENTO;

// ─────────────────────────────────────────
// ESTADO DE SESSÃO POR USUÁRIO
// ─────────────────────────────────────────
let _estadoConversa = {};

function carregarEstadoExterno(dados) {
  if (!dados || typeof dados !== 'object') return;
  const agora = Date.now();
  for (const [jid, e] of Object.entries(dados)) {
    if (agora - (e.ts || 0) < TIMEOUT_ESTADO_MS) _estadoConversa[jid] = e;
  }
  console.log(`📂 ${Object.keys(_estadoConversa).length} sessões restauradas.`);
}

function exportarEstado() { return { ..._estadoConversa }; }

function getEstado(jid) {
  const e = _estadoConversa[jid];
  if (!e) return null;
  if (Date.now() - e.ts > TIMEOUT_ESTADO_MS) { delete _estadoConversa[jid]; return null; }
  return e;
}

function setEstado(jid, menu, extra = {}) {
  _estadoConversa[jid] = {
    ...(_estadoConversa[jid] || { erros: 0, sentimento: 'neutro' }),
    menu,
    ts: Date.now(),
    ...extra,
  };
}

function resetEstado(jid) { delete _estadoConversa[jid]; }

function registrarErro(jid) {
  if (!_estadoConversa[jid]) _estadoConversa[jid] = { menu: null, ts: Date.now(), erros: 0, sentimento: 'neutro' };
  _estadoConversa[jid].erros = (_estadoConversa[jid].erros || 0) + 1;
  _estadoConversa[jid].ts = Date.now();
  return _estadoConversa[jid].erros;
}

function registrarSentimento(jid, s) {
  if (!_estadoConversa[jid]) _estadoConversa[jid] = { menu: null, ts: Date.now(), erros: 0, sentimento: 'neutro' };
  _estadoConversa[jid].sentimento = s;
}

function ehUsuarioNovo(jid) { return !_estadoConversa[jid]; }

// Retorna dados coletados no fluxo (se houver)
function getDadosFormulario(jid) {
  const e = _estadoConversa[jid];
  return {
    nome:   e?.nome   || '',
    email:  e?.email  || '',
    tel:    e?.tel    || '',
    cidade: e?.cidade || '',
    // Adicione mais campos conforme seu fluxo
  };
}

// ─────────────────────────────────────────
// DETECÇÃO DE SENTIMENTO
// ─────────────────────────────────────────
const PALAVRAS_URGENTE  = ['urgente','urgencia','rapido','preciso ja','preciso agora','hoje','imediato','logo','quanto antes'];
const PALAVRAS_IRRITADO = ['absurdo','ridiculo','pessimo','horrivel','nao funciona','travou','bugou','impossivel','problema','raiva','indignado','vergonha'];
const PALAVRAS_ANSIOSO  = ['ansioso','ansiosa','nervoso','nervosa','preocupado','sera que','tenho medo','nao sei','confuso','perdido'];

function detectarSentimento(msg) {
  if (PALAVRAS_IRRITADO.some(p => msg.includes(p))) return 'irritado';
  if (PALAVRAS_URGENTE.some(p  => msg.includes(p))) return 'urgente';
  if (PALAVRAS_ANSIOSO.some(p  => msg.includes(p))) return 'ansioso';
  return 'neutro';
}

function prefixoSentimento(s) {
  if (s === 'irritado') return `Entendo sua frustração e quero te ajudar da melhor forma. 🙏\n\n`;
  if (s === 'urgente')  return `Entendido, vou te ajudar o mais rápido possível! ⚡\n\n`;
  if (s === 'ansioso')  return `Fique tranquilo(a), estou aqui para te orientar. 😊\n\n`;
  return '';
}

// ─────────────────────────────────────────
// NORMALIZAÇÃO E FUZZY MATCH
// ─────────────────────────────────────────
function norm(str) {
  return (str || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s*#]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = a[i-1] === b[j-1]
        ? dp[i-1][j-1]
        : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
  return dp[m][n];
}

function fuzzyMatch(msg, lista) {
  return lista.some(p => {
    if (msg.includes(p)) return true;
    if (p.length >= 5) return msg.split(' ').some(w => w.length >= 4 && levenshtein(w, p) <= 2);
    return false;
  });
}

// ─────────────────────────────────────────
// PALAVRAS-CHAVE (personalize conforme seu negócio)
// ─────────────────────────────────────────
const PALAVRAS_MENU      = ['oi','ola','oii','opa','eai','bom dia','boa tarde','boa noite','menu','inicio','comecar','voltar','hello','hi','hey','ajuda','help','start'];
const PALAVRAS_SERVICOS  = ['servico','servicos','produto','produtos','o que voce faz','como funciona'];
const PALAVRAS_CONTATO   = ['contato','falar','atendente','humano','pessoa','atendimento'];
const PALAVRAS_PRECO     = ['preco','valor','quanto custa','orcamento','plano','planos','tabela'];
const PALAVRAS_OBRIGADO  = ['obrigado','obrigada','valeu','vlw','tmj','grato','grata'];

// ─────────────────────────────────────────
// SEPARADOR VISUAL
// ─────────────────────────────────────────
const SEP = '━━━━━━━━━━━━━━━━━━━━━';

// ─────────────────────────────────────────
// ✏️  MENU PRINCIPAL
// Personalize as opções para o seu negócio
// ─────────────────────────────────────────
const MENU_PRINCIPAL = `${SEP}
Olá! Bem-vindo(a) à *${CFG.EMPRESA.NOME}*! 👋
_${CFG.EMPRESA.SLOGAN}_

Como posso te ajudar?

1️⃣ Nossos serviços / produtos
2️⃣ Preços e planos
3️⃣ Como funciona
4️⃣ Perguntas frequentes (FAQ)
5️⃣ Falar com atendente

0️⃣ Encerrar conversa

_Digite o número da opção desejada:_
${SEP}`;

const MENU_BOAS_VINDAS = `${SEP}
✨ *Primeira vez aqui? Seja bem-vindo(a)!*

Sou o assistente virtual da *${CFG.EMPRESA.NOME}*.
Estou aqui para te ajudar! 😊

1️⃣ Nossos serviços / produtos
2️⃣ Preços e planos
3️⃣ Como funciona
4️⃣ Perguntas frequentes (FAQ)
5️⃣ Falar com atendente

0️⃣ Encerrar conversa

_Digite o número para começar:_
${SEP}`;

const MENU_PRINCIPAL_RETORNO = `⏰ *Sessão retomada!*\n\n${MENU_PRINCIPAL}`;

// ─────────────────────────────────────────
// ✏️  FLUXO MULTI-ETAPAS
// Exemplo: coleta nome, telefone e e-mail
// Adapte as etapas para o seu processo
// ─────────────────────────────────────────
const FLUXO = {

  inicio: () => `${SEP}
📋 *FORMULÁRIO — PASSO 1 de 3*

Para continuar, preciso de algumas informações.

Qual é o seu *nome completo*?
${SEP}`,

  nome_ok: (nome) => `Olá, *${nome}*! 👋

${SEP}
📋 *FORMULÁRIO — PASSO 2 de 3*

Qual é o seu *telefone* (com DDD)?
_(ex: (51) 99999-9999)_
${SEP}`,

  tel_ok: (nome, tel) => `${SEP}
📋 *FORMULÁRIO — PASSO 3 de 3*

*Nome:* ${nome}
*Telefone:* ${tel}

Qual é o seu *e-mail*?
_(para receber o retorno)_
${SEP}`,

  sucesso: (nome, tel, email) => `${SEP}
✅ *Recebemos suas informações!*

👤 *Nome:* ${nome}
📱 *Telefone:* ${tel}
📧 *E-mail:* ${email}

Nossa equipe entrará em contato em breve. 😊

Obrigado, *${nome.split(' ')[0]}*! 🙏
${SEP}
0️⃣ Voltar ao menu`,

};

// ─────────────────────────────────────────
// ✏️  RESPOSTAS DOS MENUS FIXOS
// Edite cada resposta para o seu negócio
// ─────────────────────────────────────────
const RESPOSTAS = {

  '1': `${SEP}
🛍️ *NOSSOS SERVIÇOS*

Descreva aqui os seus serviços ou produtos.

• Serviço/Produto A — descrição breve
• Serviço/Produto B — descrição breve
• Serviço/Produto C — descrição breve

🌐 Saiba mais:
👉 ${CFG.EMPRESA.SITE}
${SEP}
0️⃣ Menu principal`,

  '2': `${SEP}
💰 *PREÇOS E PLANOS*

Informe aqui seus preços, planos ou tabela.

• Plano Básico — R$ 0,00/mês
• Plano Pro    — R$ 0,00/mês
• Plano Plus   — R$ 0,00/mês

📲 Quer um orçamento personalizado?
👉 https://wa.me/55${ATEND}
${SEP}
0️⃣ Menu principal`,

  '3': `${SEP}
🤔 *COMO FUNCIONA*

Explique aqui o seu processo, passo a passo:

*1.* Primeiro passo
*2.* Segundo passo
*3.* Terceiro passo
*4.* Resultado / entrega

💡 Ficou com dúvidas? Digite *4* para ver o FAQ
ou *5* para falar com a gente!
${SEP}
0️⃣ Menu principal`,

  '4': `${SEP}
❓ *PERGUNTAS FREQUENTES*

*1. Pergunta exemplo 1?*
Resposta da pergunta 1.

*2. Pergunta exemplo 2?*
Resposta da pergunta 2.

*3. Pergunta exemplo 3?*
Resposta da pergunta 3.

*4. Como entrar em contato?*
Digite *5* ou fale conosco:
👉 https://wa.me/55${ATEND}
${SEP}
0️⃣ Menu principal`,

  '5': `${SEP}
🎧 *ATENDIMENTO HUMANO*

Nosso time está pronto para te ajudar!

📲 *WhatsApp:*
👉 https://wa.me/55${ATEND}

🌐 *Formulário de contato:*
👉 ${CFG.EMPRESA.SITE}

🕐 Seg a Sex, 09h às 18h
${SEP}
0️⃣ Menu principal`,

  '0': `${SEP}
👋 *Até logo!*

Obrigado por falar com a *${CFG.EMPRESA.NOME}*!

Se precisar de algo, é só mandar um *oi*. 😊
${SEP}`,

  'agradecimento': `De nada! 😊 Se precisar de mais alguma coisa,
é só digitar *menu*. Estamos aqui!`,

  'escalada': `Parece que não estou conseguindo te ajudar
como você merece. 😔

Que tal falar diretamente com nossa equipe?

📲 *Atendimento humano:*
👉 https://wa.me/55${ATEND}

Ou digite *menu* para recomeçar. 😊`,

};

// ─────────────────────────────────────────
// MENSAGENS DE REFORMULAÇÃO (quando não entende)
// ─────────────────────────────────────────
const REFORMULACOES = [
  `Hmm, não entendi direito o que você precisa. 🤔\n\nPode reformular?\n\nOu digite *menu* para ver todas as opções.`,
  `Ainda não consegui entender. 😅\n\nTente descrever com outras palavras,\nou digit *0* para falar com um atendente.`,
  `Não estou conseguindo captar o que você quer dizer. 🤷\n\nDigite *menu* para recomeçar ou *5* para falar com nossa equipe.`,
];

function mensagemReformulacao(t) {
  return REFORMULACOES[Math.min(t - 1, REFORMULACOES.length - 1)];
}

// ─────────────────────────────────────────
// RESET AUTOMÁTICO DE SESSÕES EXPIRADAS
// ─────────────────────────────────────────
function verificarResetsAutomaticos() {
  const agora = Date.now();
  for (const [jid, e] of Object.entries(_estadoConversa)) {
    if (agora - e.ts > TIMEOUT_ESTADO_MS) {
      delete _estadoConversa[jid];
      console.log(`🧹 Sessão expirada: ${jid}`);
    }
  }
}

// ─────────────────────────────────────────
// LÓGICA PRINCIPAL DE RESPOSTAS
// ─────────────────────────────────────────
function obterResposta(texto, jid = '') {
  if (!texto || typeof texto !== 'string') return MENU_PRINCIPAL;

  const raw        = texto.trim();
  const msg        = norm(raw);
  const estadoObj  = jid ? getEstado(jid) : null;
  const estadoMenu = estadoObj?.menu || null;

  const sentimento = detectarSentimento(msg);
  if (jid && sentimento !== 'neutro') registrarSentimento(jid, sentimento);
  const prefixo = prefixoSentimento(sentimento);

  // ── Encerrar ──────────────────────────
  if (['encerrar','sair','tchau','flw','bye'].includes(msg)) {
    if (jid) resetEstado(jid);
    return RESPOSTAS['0'];
  }

  // ── Agradecimentos ────────────────────
  if (PALAVRAS_OBRIGADO.some(p => msg === p || msg.includes(p))) {
    return RESPOSTAS['agradecimento'];
  }

  // ── FLUXO MULTI-ETAPAS ───────────────
  // Etapa 1: coleta nome
  if (estadoMenu === 'form_nome') {
    const nome = raw;
    _estadoConversa[jid] = { menu: 'form_tel', ts: Date.now(), erros: 0, sentimento: 'neutro', nome };
    return FLUXO.nome_ok(nome);
  }

  // Etapa 2: coleta telefone
  if (estadoMenu === 'form_tel') {
    const tel = raw.replace(/\D/g, '');
    if (tel.length < 10 || tel.length > 13) {
      return `❌ Telefone inválido. Informe com DDD.\n\n_Exemplo: (51) 99999-9999_`;
    }
    const telFormatado = tel.replace(/^(\d{2})(\d{4,5})(\d{4})$/, '($1) $2-$3');
    const nome = estadoObj.nome;
    _estadoConversa[jid] = { menu: 'form_email', ts: Date.now(), erros: estadoObj.erros || 0, sentimento: estadoObj.sentimento || 'neutro', nome, tel, telFormatado };
    return FLUXO.tel_ok(nome, telFormatado);
  }

  // Etapa 3: coleta e-mail e finaliza
  if (estadoMenu === 'form_email') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(raw.trim())) {
      return `❌ E-mail inválido.\n\n_Exemplo: seunome@email.com_`;
    }
    const email = raw.trim();
    const { nome, telFormatado } = estadoObj;

    // Aqui você pode salvar os dados (Supabase, planilha, etc.)
    // Veja o arquivo formulario.js para exemplos de integração

    if (jid) resetEstado(jid);
    return FLUXO.sucesso(nome, telFormatado, email);
  }

  // Aguardando arquivo (PDF/imagem) — adaptável
  if (estadoMenu === 'form_aguardando_arquivo') {
    return `📎 Aguardando o seu arquivo...\n\nSe quiser cancelar, digite *0* para voltar ao menu.`;
  }

  // ── Atalho para iniciar fluxo ─────────
  // Mude 'F' para a letra/palavra que preferir
  if (msg === 'f' || msg === 'formulario' || msg === 'quero continuar') {
    if (jid) setEstado(jid, 'form_nome');
    return FLUXO.inicio();
  }

  // ── Opção 0 ───────────────────────────
  if (msg === '0') {
    if (estadoMenu && estadoMenu !== 'menu') {
      if (jid) setEstado(jid, 'menu');
      return prefixo + MENU_PRINCIPAL;
    }
    if (jid) resetEstado(jid);
    return prefixo + RESPOSTAS['0'];
  }

  // ── Opções numéricas do menu ──────────
  if (msg === '1') { if (jid) setEstado(jid, '1'); return prefixo + RESPOSTAS['1']; }
  if (msg === '2') { if (jid) setEstado(jid, '2'); return prefixo + RESPOSTAS['2']; }
  if (msg === '3') { if (jid) setEstado(jid, '3'); return prefixo + RESPOSTAS['3']; }
  if (msg === '4') { if (jid) setEstado(jid, '4'); return prefixo + RESPOSTAS['4']; }
  if (msg === '5') { if (jid) setEstado(jid, '5'); return prefixo + RESPOSTAS['5']; }

  // ── Saudações / menu ──────────────────
  if (PALAVRAS_MENU.some(p => msg === p || msg.startsWith(p + ' ') || msg.endsWith(' ' + p))) {
    const novo = jid && ehUsuarioNovo(jid);
    if (jid) setEstado(jid, 'menu');
    return prefixo + (novo ? MENU_BOAS_VINDAS : MENU_PRINCIPAL);
  }

  // Emoji puro (vira espaço após normalização)
  if (msg === '') { if (jid) resetEstado(jid); return MENU_PRINCIPAL; }

  // ── Fuzzy match por intenção ──────────
  if (fuzzyMatch(msg, PALAVRAS_SERVICOS)) { if (jid) setEstado(jid, '1'); return prefixo + RESPOSTAS['1']; }
  if (fuzzyMatch(msg, PALAVRAS_PRECO))    { if (jid) setEstado(jid, '2'); return prefixo + RESPOSTAS['2']; }
  if (fuzzyMatch(msg, PALAVRAS_CONTATO))  { if (jid) setEstado(jid, '5'); return prefixo + RESPOSTAS['5']; }

  // ── Não entendeu → reformulação / escalada ──
  const tentativa = jid ? registrarErro(jid) : 1;
  if (tentativa >= 3) { if (jid) resetEstado(jid); return RESPOSTAS['escalada']; }
  return prefixo + mensagemReformulacao(tentativa);
}

module.exports = {
  MENU_PRINCIPAL,
  MENU_PRINCIPAL_RETORNO,
  FLUXO,
  obterResposta,
  verificarResetsAutomaticos,
  carregarEstadoExterno,
  exportarEstado,
  getDadosFormulario,
  getEstado,
  resetEstado,
};
