// index.js — WhatsApp Bot
// Ponto de entrada principal
'use strict';

const {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  downloadMediaMessage,
} = require('@whiskeysockets/baileys');

const qrcode = require('qrcode-terminal');
const QRCode  = require('qrcode');
const pino    = require('pino');
const fs      = require('fs');

const CFG = require('./config');
const {
  obterResposta,
  verificarResetsAutomaticos,
  MENU_PRINCIPAL_RETORNO,
  carregarEstadoExterno,
  exportarEstado,
  getDadosFormulario,
  getEstado,
  resetEstado,
  FLUXO,
} = require('./menu');

const { processarArquivoWhatsApp } = require('./formulario');

// ─────────────────────────────────────────
// ESTADO PERSISTENTE
// ─────────────────────────────────────────
let state = { pausado: false, humanAtivos: {}, ultimaMensagem: {} };

function carregarState() {
  try {
    if (fs.existsSync(CFG.STATE_FILE)) {
      const dados = JSON.parse(fs.readFileSync(CFG.STATE_FILE, 'utf8'));
      state = { ...state, ...dados };
      if (dados.estadoConversa) carregarEstadoExterno(dados.estadoConversa);
      console.log('📂 Estado carregado.');
    }
  } catch (e) { console.warn('⚠️  Não foi possível carregar estado:', e.message); }
}

function salvarState() {
  try {
    fs.writeFileSync(CFG.STATE_FILE, JSON.stringify({
      ...state,
      estadoConversa: exportarEstado(),
    }, null, 2));
  } catch (e) { console.warn('⚠️  Erro ao salvar estado:', e.message); }
}

// ─────────────────────────────────────────
// LOG
// ─────────────────────────────────────────
function logConversa(de, texto, dir = 'IN') {
  const linha = `[${new Date().toISOString()}] [${dir}] ${de}: ${texto}\n`;
  process.stdout.write(dir === 'IN'
    ? `📩 [${new Date().toLocaleTimeString()}] ${de}: ${texto}\n`
    : `📤 [${new Date().toLocaleTimeString()}] → ${de}\n`
  );
  try { fs.appendFileSync(CFG.LOG_FILE, linha); } catch (_) {}
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────
const pessoalJid = () => `${CFG.ADMIN_PESSOAL}@s.whatsapp.net`;
const botJid     = () => `${CFG.BOT_NUMBER}@s.whatsapp.net`;

async function alertarAdmin(sock, texto) {
  try { await sock.sendMessage(pessoalJid(), { text: texto }); } catch (_) {}
}

function emAtendimentoHumano(jid) {
  const ts = state.humanAtivos[jid];
  if (!ts) return false;
  if (CFG.HUMAN_TAKEOVER_TIMEOUT_MS > 0 && Date.now() - ts > CFG.HUMAN_TAKEOVER_TIMEOUT_MS) {
    delete state.humanAtivos[jid];
    salvarState();
    return false;
  }
  return true;
}

function ativarHumano(jid)    { state.humanAtivos[jid] = Date.now(); salvarState(); }
function desativarHumano(jid) { delete state.humanAtivos[jid]; salvarState(); }

function antiSpam(jid) {
  const agora = Date.now();
  const ultimo = state.ultimaMensagem[jid] || 0;
  state.ultimaMensagem[jid] = agora;
  return (agora - ultimo) < CFG.ANTI_SPAM_MS;
}

function limparAntiSpam() {
  const limite = Date.now() - 60_000;
  let r = 0;
  for (const jid of Object.keys(state.ultimaMensagem)) {
    if (state.ultimaMensagem[jid] < limite) { delete state.ultimaMensagem[jid]; r++; }
  }
  if (r > 0) console.log(`🧹 Anti-spam: ${r} entradas removidas.`);
}

async function enviarComTyping(sock, jid, texto) {
  const delay = CFG.TYPING_DELAY_BASE + Math.random() * CFG.TYPING_DELAY_EXTRA;
  await sock.sendPresenceUpdate('composing', jid);
  await new Promise(r => setTimeout(r, delay));
  await sock.sendPresenceUpdate('paused', jid);
  await sock.sendMessage(jid, { text: texto });
  logConversa(jid, texto.substring(0, 80) + (texto.length > 80 ? '…' : ''), 'OUT');
}

// ─────────────────────────────────────────
// COMANDOS DO ADMIN (via WhatsApp)
// ─────────────────────────────────────────
async function processarComandoAdmin(sock, texto, from) {
  const cmd = texto.trim().toLowerCase();

  if (cmd === '!pausar') {
    state.pausado = true; salvarState();
    return '⏸️ Bot *pausado*. Nenhuma mensagem será respondida até !retomar.';
  }
  if (cmd === '!retomar') {
    state.pausado = false; salvarState();
    return '▶️ Bot *retomado*! Respondendo automaticamente.';
  }
  if (cmd === '!status') {
    const humanos = Object.keys(state.humanAtivos);
    return `📊 *Status do Bot*\n\n` +
      `• Estado: ${state.pausado ? '⏸️ Pausado' : '✅ Ativo'}\n` +
      `• Atendimentos humanos: ${humanos.length}\n` +
      `• Anti-spam: ${CFG.ANTI_SPAM_MS}ms\n` +
      `• Timeout humano: ${CFG.HUMAN_TAKEOVER_TIMEOUT_MS / 60000} min`;
  }
  if (cmd === '!lista') {
    const humanos = Object.keys(state.humanAtivos);
    if (!humanos.length) return '📋 Nenhum número em atendimento humano.';
    return `📋 *Atendimentos humanos ativos:*\n\n` +
      humanos.map(jid => {
        const num = jid.replace('@s.whatsapp.net', '');
        const min = Math.round((Date.now() - state.humanAtivos[jid]) / 60000);
        return `• +${num} (há ${min} min)`;
      }).join('\n');
  }
  if (cmd.startsWith('!humano')) {
    const num = texto.replace(/!humano\s*/i, '').replace(/\D/g, '');
    if (!num) return '❌ Informe o número. Ex: !humano 5551999999999';
    const jidAlvo = `${num}@s.whatsapp.net`;
    ativarHumano(jidAlvo);
    try {
      await sock.sendMessage(jidAlvo, {
        text: `👤 Um atendente está disponível para você agora! Pode falar diretamente. 😊`
      });
    } catch (_) {}
    return `👤 Atendimento humano *ativado* para +${num}. Usuário notificado.`;
  }
  if (cmd.startsWith('!bot')) {
    const num = texto.replace(/!bot\s*/i, '').replace(/\D/g, '');
    if (!num) return '❌ Informe o número. Ex: !bot 5551999999999';
    const jidAlvo = `${num}@s.whatsapp.net`;
    desativarHumano(jidAlvo);
    try {
      await sock.sendMessage(jidAlvo, {
        text: `🤖 Você voltou ao atendimento automático! Digite *menu* para ver as opções. 😊`
      });
    } catch (_) {}
    return `🤖 Bot *reativado* para +${num}. Usuário notificado.`;
  }
  if (cmd === '!logs') {
    try {
      if (!fs.existsSync(CFG.LOG_FILE)) return '📋 Nenhum log disponível ainda.';
      const linhas  = fs.readFileSync(CFG.LOG_FILE, 'utf8').trim().split('\n');
      const ultimas = linhas.slice(-20).join('\n');
      const truncado = ultimas.length > CFG.LOG_MAX_CHARS
        ? '...(truncado)\n' + ultimas.slice(-CFG.LOG_MAX_CHARS) : ultimas;
      return `📋 *Últimas ${Math.min(20, linhas.length)} mensagens:*\n\n\`\`\`${truncado}\`\`\``;
    } catch (e) { return '❌ Erro ao ler log: ' + e.message; }
  }
  if (cmd.startsWith('!')) {
    return `🤖 *Comandos disponíveis:*\n\n` +
      `*!pausar* — pausa o bot\n` +
      `*!retomar* — retoma o bot\n` +
      `*!humano 55XXXXX* — ativa atendimento humano\n` +
      `*!bot 55XXXXX* — devolve ao bot\n` +
      `*!status* — estado atual\n` +
      `*!lista* — atendimentos humanos ativos\n` +
      `*!logs* — últimas 20 mensagens`;
  }
  return null;
}

// ─────────────────────────────────────────
// FILA POR JID (evita mensagens fora de ordem)
// ─────────────────────────────────────────
const _filas = new Map();
async function enfileirar(jid, fn) {
  const anterior = _filas.get(jid) || Promise.resolve();
  const proxima  = anterior.then(fn).catch(e => console.error(`❌ Fila ${jid}:`, e.message));
  _filas.set(jid, proxima);
  await proxima;
  if (_filas.get(jid) === proxima) _filas.delete(jid);
}

// ─────────────────────────────────────────
// PROCESSAMENTO DE ARQUIVO RECEBIDO
// Adapte a lógica conforme o fluxo do seu bot
// ─────────────────────────────────────────
async function processarArquivo(sock, msg, from) {
  await enviarComTyping(sock, from,
    `📥 Recebi seu arquivo! Processando... ⏳\n\n_Aguarde um momento._`
  );

  try {
    const docMsg   = msg.message?.documentMessage || msg.message?.imageMessage;
    const mimeType = docMsg?.mimetype || 'application/pdf';
    const nomeOrig = docMsg?.fileName || (msg.message?.imageMessage ? 'arquivo.jpg' : 'arquivo.pdf');

    const stream = await downloadMediaMessage(msg, 'buffer', {});
    const buffer = Buffer.isBuffer(stream) ? stream : Buffer.from(stream);

    const dadosForm  = getDadosFormulario(from);
    const resultado  = await processarArquivoWhatsApp(buffer, mimeType, nomeOrig, from, dadosForm);

    resetEstado(from);

    // ✏️ Edite a mensagem de sucesso conforme seu negócio
    await enviarComTyping(sock, from,
      `✅ *Arquivo recebido com sucesso!*\n\n` +
      `Obrigado, *${resultado.nome || 'cliente'}*!\n` +
      `Nossa equipe entrará em contato em breve. 😊\n\n` +
      `0️⃣ Voltar ao menu`
    );

    // Alerta ao admin
    await alertarAdmin(sock,
      `📄 *Arquivo recebido*\n\n` +
      `👤 Nome: ${resultado.nome}\n` +
      `📱 Tel: +${from.replace('@s.whatsapp.net', '')}\n` +
      (resultado.arquivoUrl ? `🔗 Arquivo: ${resultado.arquivoUrl}` : '')
    );

  } catch (err) {
    console.error('❌ Erro ao processar arquivo:', err.message);
    await enviarComTyping(sock, from,
      `😕 Ocorreu um erro ao processar seu arquivo.\n\n` +
      `Tente novamente ou acesse:\n👉 ${CFG.EMPRESA.SITE}`
    );
  }
}

// ─────────────────────────────────────────
// BOT PRINCIPAL
// ─────────────────────────────────────────
async function iniciarBot() {
  carregarState();

  const encerrar = (s) => { console.log(`🛑 ${s}`); salvarState(); process.exit(0); };
  process.on('SIGTERM', () => encerrar('SIGTERM'));
  process.on('SIGINT',  () => encerrar('SIGINT'));
  process.on('uncaughtException',  (e) => { console.error('❌', e.message); salvarState(); process.exit(1); });
  process.on('unhandledRejection', (r) => console.error('❌ Promise:', r));

  const { state: authState, saveCreds } = await useMultiFileAuthState('auth_info');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: authState,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    browser: ['Chrome (Linux)', '', ''],
  });

  sock.ev.on('creds.update', saveCreds);

  setInterval(verificarResetsAutomaticos, 2 * 60 * 1000);
  setInterval(limparAntiSpam,             CFG.ANTI_SPAM_CLEANUP_MS);
  setInterval(salvarState,                5 * 60 * 1000);

  // ── Conexão ──────────────────────────
  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      console.log('\n📱 Escaneie o QR Code com seu WhatsApp:\n');
      qrcode.generate(qr, { small: true });
      QRCode.toFile(CFG.QR_FILE, qr, { width: 512, margin: 2 }, (err) => {
        if (err) console.warn('⚠️  Não foi possível salvar qrcode.png:', err.message);
        else console.log('🖼️  QR Code salvo como qrcode.png — baixe e escaneie.');
      });
    }
    if (connection === 'close') {
      const codigo     = lastDisconnect?.error?.output?.statusCode;
      const reconectar = codigo !== DisconnectReason.loggedOut;
      console.log(`⚠️  Conexão encerrada (${codigo}). Reconectando: ${reconectar}`);
      if (reconectar) setTimeout(iniciarBot, 3000);
    }
    if (connection === 'open') {
      try { if (fs.existsSync(CFG.QR_FILE)) fs.unlinkSync(CFG.QR_FILE); } catch (_) {}
      console.log('\n✅ Bot conectado!');
      console.log(`   📱 Número:   +${CFG.BOT_NUMBER}`);
      console.log(`   👤 Admin:    +${CFG.ADMIN_PESSOAL}`);
      console.log(`   Estado: ${state.pausado ? '⏸️ PAUSADO' : '▶️ ATIVO'}`);
      console.log(`\n   Comandos: envie !status pelo WhatsApp\n`);
    }
  });

  // ── Mensagens ────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    const msg = messages[0];
    if (!msg?.message) return;

    const from   = msg.key.remoteJid;
    const fromMe = msg.key.fromMe;

    // Ignora grupos
    if (from.endsWith('@g.us')) return;

    const texto =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      '';

    // Comandos do admin
    if (fromMe || from === pessoalJid() || from === botJid()) {
      if (texto.startsWith('!')) {
        const resposta = await processarComandoAdmin(sock, texto, from);
        if (resposta) await sock.sendMessage(from, { text: resposta });
      }
      return;
    }

    if (antiSpam(from)) { console.log(`🚫 Anti-spam: ${from}`); return; }
    if (state.pausado)  { console.log(`⏸️  Pausado: ${from}`);  return; }

    // Atendimento humano ativo — repassa ao admin
    if (emAtendimentoHumano(from)) {
      const numLimpo = from.replace('@s.whatsapp.net', '');
      await alertarAdmin(sock,
        `📩 *Mensagem nova* (atendimento humano)\n\nDe: +${numLimpo}\nMensagem: ${texto || '(mídia)'}\n\n_Para devolver ao bot: !bot ${numLimpo}_`
      );
      return;
    }

    await enfileirar(from, async () => {
      logConversa(from, texto);

      const ehPDF    = !!msg.message?.documentMessage;
      const ehImagem = !!msg.message?.imageMessage;
      const ehAudio  = !!msg.message?.audioMessage;
      const ehVideo  = !!msg.message?.videoMessage;

      // Arquivo (PDF ou imagem)
      if (!texto && (ehPDF || ehImagem)) {
        const estadoAtual      = getEstado(from);
        const aguardandoArquivo = estadoAtual?.menu === 'form_aguardando_arquivo';

        if (aguardandoArquivo) {
          await processarArquivo(sock, msg, from);
        } else {
          // ✏️ Edite a mensagem quando arquivo for enviado fora do fluxo
          await enviarComTyping(sock, from,
            `📄 Recebi seu arquivo!\n\n` +
            `Para processá-lo corretamente, inicie o atendimento:\n` +
            `_Digite_ *menu* _para ver as opções._`
          );
        }
        return;
      }

      // Áudio ou vídeo
      if (!texto && (ehAudio || ehVideo)) {
        await enviarComTyping(sock, from,
          `Olá! 👋 Nosso atendimento é feito por texto.\n\nDigite *menu* para ver as opções. 😊`
        );
        return;
      }

      if (!texto) return;

      // Opção 0 fora de submenu → alerta admin para atendimento humano
      if (texto.trim() === '0') {
        const numLimpo = from.replace('@s.whatsapp.net', '');
        await alertarAdmin(sock,
          `🔔 *Pedido de atendimento humano*\n\nDe: +${numLimpo}\n\n_Para assumir: !humano ${numLimpo}_`
        );
      }

      const resposta = obterResposta(texto, from);
      await enviarComTyping(sock, from, resposta);
    });
  });
}

iniciarBot();
