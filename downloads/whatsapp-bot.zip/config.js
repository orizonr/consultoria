// config.js — WhatsApp Bot
// Edite aqui para configurar o bot para o seu negócio
'use strict';

module.exports = {

  EMPRESA: {
    NOME:      'Minha Empresa',           // Nome da sua empresa
    SLOGAN:    'Slogan da sua empresa',   // Slogan ou descrição curta
    SITE:      'https://meusite.com.br',  // Site principal
    INSTAGRAM: 'https://instagram.com/minhaempresa',
    WHATSAPP:  'https://wa.me/55XXXXXXXXXXX',
  },

  // Número que RODA o bot (somente dígitos, sem + ou espaços)
  BOT_NUMBER:    '55XXXXXXXXXXX',

  // Celular do admin que recebe alertas e usa comandos !
  ADMIN_PESSOAL: '55XXXXXXXXXXX',

  // WhatsApp exibido nos menus para atendimento humano
  ATENDIMENTO:   '55XXXXXXXXXXX',

  // (Opcional) Integração com Google Apps Script para salvar arquivos no Drive
  // Deixe vazio '' se não for usar
  WEBAPP_ARQUIVO: '',

  // (Opcional) Supabase — banco de dados online gratuito
  // Deixe vazio '' se não for usar
  SUPABASE_URL: '',
  SUPABASE_KEY: '',
  SUPABASE_TABLE: 'registros',

  // ─── Comportamento ───────────────────────────────────────────────
  // Tempo de "digitando..." antes de enviar (em ms)
  TYPING_DELAY_BASE:  800,
  TYPING_DELAY_EXTRA: 600,

  // Intervalo mínimo entre mensagens do mesmo usuário (anti-spam)
  ANTI_SPAM_MS:         3000,
  ANTI_SPAM_CLEANUP_MS: 10 * 60 * 1000,  // limpeza a cada 10 min

  // Tempo máximo de atendimento humano ativo (30 min)
  HUMAN_TAKEOVER_TIMEOUT_MS: 30 * 60 * 1000,

  // Sessão de conversa expira após inatividade (20 min)
  TIMEOUT_ESTADO_MS: 20 * 60 * 1000,

  // Máximo de caracteres exibidos no comando !logs
  LOG_MAX_CHARS: 3500,

  // Arquivos gerados pelo bot
  LOG_FILE:   'conversas.log',
  STATE_FILE: 'bot_state.json',
  QR_FILE:    'qrcode.png',
};
