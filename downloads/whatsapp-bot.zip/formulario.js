// formulario.js — WhatsApp Bot
// Processa arquivos recebidos e salva dados do formulário
// Adapte as integrações para o seu negócio
'use strict';

const CFG = require('./config');

// ─────────────────────────────────────────
// SALVAR NO SUPABASE (opcional)
// Configure SUPABASE_URL, SUPABASE_KEY e SUPABASE_TABLE no config.js
// ─────────────────────────────────────────
async function salvarNoSupabase(dados) {
  if (!CFG.SUPABASE_URL || !CFG.SUPABASE_KEY) {
    console.log('ℹ️  Supabase não configurado. Pulando...');
    return null;
  }

  const hoje = new Date();
  const payload = {
    nome:      dados.nome      || '',
    email:     dados.email     || null,
    telefone:  dados.telefone  || '',
    cidade:    dados.cidade    || null,
    arquivo_url: dados.arquivoUrl || '',
    origem:    'WhatsApp',
    criado_em: hoje.toISOString(),
    // Adicione mais campos conforme sua tabela no Supabase
  };

  console.log('📤 Salvando no Supabase:', JSON.stringify({ nome: payload.nome }));

  const res = await fetch(`${CFG.SUPABASE_URL}/rest/v1/${CFG.SUPABASE_TABLE}`, {
    method: 'POST',
    headers: {
      'apikey':        CFG.SUPABASE_KEY,
      'Authorization': 'Bearer ' + CFG.SUPABASE_KEY,
      'Content-Type':  'application/json',
      'Prefer':        'return=representation',
    },
    body: JSON.stringify(payload),
  });

  const txt = await res.text();
  if (!res.ok) throw new Error(`Supabase ${res.status}: ${txt}`);

  let criado;
  try { criado = JSON.parse(txt); } catch (_) { criado = []; }
  console.log(`✅ Registro salvo no Supabase: ${payload.nome}`);
  return criado[0] || payload;
}

// ─────────────────────────────────────────
// ENVIAR ARQUIVO PARA GOOGLE APPS SCRIPT (opcional)
// Configure WEBAPP_ARQUIVO no config.js e use um Apps Script
// que receba base64 e salve no Google Drive
// ─────────────────────────────────────────
async function enviarParaAppScript(buffer, mimeType, nomeOriginal, telefone, dadosExtra = {}) {
  if (!CFG.WEBAPP_ARQUIVO) {
    console.log('ℹ️  WEBAPP_ARQUIVO não configurado. Pulando upload...');
    return null;
  }

  const base64 = buffer.toString('base64');

  const payload = {
    arquivo:  base64,
    mimeType: mimeType      || 'application/pdf',
    nomeOrig: nomeOriginal  || 'arquivo.pdf',
    telefone: telefone,
    nome:     dadosExtra.nome  || '',
    email:    dadosExtra.email || '',
    // Adicione campos extras conforme seu Apps Script
  };

  console.log(`📤 Enviando arquivo para Apps Script: ${payload.nome}`);

  const res = await fetch(CFG.WEBAPP_ARQUIVO, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(payload),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Apps Script status ${res.status}: ${txt}`);
  }

  const data = await res.json();
  if (!data.ok) throw new Error('Apps Script retornou erro: ' + (data.erro || 'desconhecido'));

  console.log(`✅ Arquivo salvo no Drive: ${data.linkDrive}`);
  return data.linkDrive || null;
}

// ─────────────────────────────────────────
// FUNÇÃO PRINCIPAL
// Chame esta função quando receber um arquivo via WhatsApp
// ─────────────────────────────────────────
async function processarArquivoWhatsApp(buffer, mimeType, nomeOriginal, jid, dadosFormulario = {}) {
  const telefone = jid.replace('@s.whatsapp.net', '').replace(/\D/g, '');

  // 1. (Opcional) Upload no Google Drive via Apps Script
  let arquivoUrl = null;
  if (CFG.WEBAPP_ARQUIVO) {
    arquivoUrl = await enviarParaAppScript(buffer, mimeType, nomeOriginal, telefone, dadosFormulario);
  }

  // 2. (Opcional) Salvar no Supabase
  if (CFG.SUPABASE_URL) {
    try {
      await salvarNoSupabase({
        nome:       dadosFormulario.nome   || '',
        email:      dadosFormulario.email  || '',
        telefone:   dadosFormulario.tel    || telefone,
        cidade:     dadosFormulario.cidade || '',
        arquivoUrl: arquivoUrl             || '',
      });
    } catch (err) {
      console.error('❌ ERRO Supabase (arquivo no Drive está OK):', err.message);
    }
  }

  return {
    ok:         true,
    arquivoUrl: arquivoUrl || '',
    nome:       dadosFormulario.nome  || '',
    telefone:   dadosFormulario.tel   || telefone,
    email:      dadosFormulario.email || '',
  };
}

module.exports = { processarArquivoWhatsApp };
